<section class="p-10 flex flex-col items-center justify-center">

    <h2
        class="mb-6 text-4xl lg:text-8xl tracking-tight font-extrabold text-orange-100 [text-shadow:_4px_4px_0_rgb(0_0_0)]">
        Competitions</h2>

    {{-- <div
        class="flex w-[300px] h-[120px] md:w-[400px] lg:w-[85vw] lg:h-[12rem] lg:justify-between items-center lg:border-[5px] border-emerald-200 mb-10 p-5 shadow-2xl bg-white">
        <div
            class="flex h-16 w-16 items-center justify-center bg-emerald-400 shadow-gray-950 lg:h-[150px] lg:w-[150px]">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-28 h-28" fill="none" viewBox="0 0 24 24">
                <path fill="#1C274C" fill-rule="evenodd"
                    d="M4.172 3.172C3 4.343 3 6.229 3 10v4c0 3.771 0 5.657 1.172 6.828C5.343 22 7.229 22 11 22h2c3.771 0 5.657 0 6.828-1.172C21 19.657 21 17.771 21 14v-4c0-3.771 0-5.657-1.172-6.828C18.657 2 16.771 2 13 2h-2C7.229 2 5.343 2 4.172 3.172ZM7.25 8A.75.75 0 0 1 8 7.25h8a.75.75 0 0 1 0 1.5H8A.75.75 0 0 1 7.25 8Zm0 4a.75.75 0 0 1 .75-.75h8a.75.75 0 0 1 0 1.5H8a.75.75 0 0 1-.75-.75ZM8 15.25a.75.75 0 0 0 0 1.5h5a.75.75 0 0 0 0-1.5H8Z"
                    clip-rule="evenodd" />
            </svg>
        </div>
        <div class="flex w-[85%] flex-col justify-between lg:flex-row lg:items-center">
            <div class="ml-[8px] flex flex-col items-start justify-between">
                <h1 class="text-xl font-bold leading-[30px] text-black lg:text-5xl lg:leading-normal">
                    Lomba 1</h1>
                <h2 class="text-[10px] font-bold text-black lg:text-[20px] ">Lomba 1
                </h2>
            </div>
            <span class="mb-[3px] flex h-[2.5px] w-full rounded bg-blue-300 lg:my-0 lg:hidden"></span>
            <div class="ml-[8px] lg:w-[55%]">
                <p class="text-[8px] text-black md:text-[10px] lg:text-end lg:text-[20px]">Lorem ipsum dolor sit amet
                    consectetur adipisicing elit. Cumque delectus quisquam consequuntur? Quidem, culpa nulla maiores
                    quia iure veritatis suscipit!</p>
            </div>
        </div>
    </div>

    <div
        class="flex w-[300px] h-[120px] md:w-[400px] lg:w-[85vw] lg:h-[12rem] lg:justify-between items-center lg:border-[5px] border-emerald-200 mb-10 p-5 shadow-2xl bg-white">
        <div
            class="flex h-16 w-16 items-center justify-center bg-emerald-400 shadow-gray-950 lg:h-[150px] lg:w-[150px]">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-28 h-28" fill="none" viewBox="0 0 24 24">
                <path fill="#1C274C" fill-rule="evenodd"
                    d="M4.172 3.172C3 4.343 3 6.229 3 10v4c0 3.771 0 5.657 1.172 6.828C5.343 22 7.229 22 11 22h2c3.771 0 5.657 0 6.828-1.172C21 19.657 21 17.771 21 14v-4c0-3.771 0-5.657-1.172-6.828C18.657 2 16.771 2 13 2h-2C7.229 2 5.343 2 4.172 3.172ZM7.25 8A.75.75 0 0 1 8 7.25h8a.75.75 0 0 1 0 1.5H8A.75.75 0 0 1 7.25 8Zm0 4a.75.75 0 0 1 .75-.75h8a.75.75 0 0 1 0 1.5H8a.75.75 0 0 1-.75-.75ZM8 15.25a.75.75 0 0 0 0 1.5h5a.75.75 0 0 0 0-1.5H8Z"
                    clip-rule="evenodd" />
            </svg>
        </div>
        <div class="flex w-[85%] flex-col justify-between lg:flex-row lg:items-center">
            <div class="ml-[8px] flex flex-col items-start justify-between">
                <h1 class="text-xl font-bold leading-[30px] text-black lg:text-5xl lg:leading-normal">
                    Lomba 1</h1>
                <h2 class="text-[10px] font-bold text-black lg:text-[20px] ">Lomba 1
                </h2>
            </div>
            <span class="mb-[3px] flex h-[2.5px] w-full rounded bg-blue-300 lg:my-0 lg:hidden"></span>
            <div class="ml-[8px] lg:w-[55%]">
                <p class="text-[8px] text-black md:text-[10px] lg:text-end lg:text-[20px]">Lorem ipsum dolor sit amet
                    consectetur adipisicing elit. Cumque delectus quisquam consequuntur? Quidem, culpa nulla maiores
                    quia iure veritatis suscipit!</p>
            </div>
        </div>
    </div> --}}



</section>
