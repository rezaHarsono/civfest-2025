<section data-aos="fade-up" class="px-24 pb-10">
    <div class="w-full bg-white border-4 rounded-3xl">
        <h1 class="text-center text-xl lg:text-4xl text-orange-800 font-bold py-10">Sponsored By</h1>
        <div class="col-span-1 flex justify-center items-center py-10">

        </div>
    </div>
</section>
